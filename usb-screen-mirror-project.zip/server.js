const http = require('http');
const fs = require('fs');
const path = require('path');

const PORT = 3000;
const ZIP_FILE = path.join(__dirname, 'usb-screen-mirror-project.zip');

const server = http.createServer((req, res) => {
    if (req.url === '/download' || req.url === '/usb-screen-mirror-project.zip') {
        if (!fs.existsSync(ZIP_FILE)) {
            res.writeHead(404, { 'Content-Type': 'text/plain' });
            return res.end('ZIP file not found. Please recreate.');
        }

        const stat = fs.statSync(ZIP_FILE);
        res.writeHead(200, {
            'Content-Type': 'application/zip',
            'Content-Disposition': 'attachment; filename="usb-screen-mirror-project.zip"',
            'Content-Length': stat.size
        });

        const readStream = fs.createReadStream(ZIP_FILE);
        return readStream.pipe(res);
    }

    // Default HTML landing page
    const zipExists = fs.existsSync(ZIP_FILE);
    const zipSize = zipExists ? (fs.statSync(ZIP_FILE).size / 1024).toFixed(1) : 0;

    const html = `<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>USB Screen Mirror - Unduh Proyek</title>
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body {
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
            background: #0c0d12;
            color: #f3f4f6;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        .card {
            background: #161822;
            border: 1px solid #2a2e3f;
            border-radius: 16px;
            max-width: 520px;
            width: 100%;
            padding: 28px;
            box-shadow: 0 10px 25px rgba(0,0,0,0.5);
        }
        .header {
            display: flex;
            align-items: center;
            gap: 12px;
            margin-bottom: 20px;
        }
        .icon {
            background: rgba(6, 182, 212, 0.2);
            color: #06b6d4;
            width: 44px;
            height: 44px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 22px;
        }
        h1 { font-size: 20px; font-weight: 700; color: #fff; }
        .subtitle { font-size: 12px; color: #9ca3af; }
        .status-badge {
            background: rgba(239, 68, 68, 0.15);
            border: 1px solid rgba(239, 68, 68, 0.3);
            color: #f87171;
            padding: 10px 14px;
            border-radius: 8px;
            font-size: 13px;
            margin-bottom: 20px;
            line-height: 1.4;
        }
        .btn-download {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            background: #06b6d4;
            color: #0c0d12;
            font-weight: 700;
            font-size: 15px;
            text-decoration: none;
            padding: 14px 20px;
            border-radius: 10px;
            text-align: center;
            transition: background 0.2s;
            margin-bottom: 20px;
        }
        .btn-download:hover { background: #22d3ee; }
        .info-box {
            background: #1e212f;
            border-radius: 10px;
            padding: 14px;
            font-size: 12px;
            color: #d1d5db;
            line-height: 1.5;
        }
        .info-box h3 {
            color: #06b6d4;
            margin-bottom: 6px;
            font-size: 13px;
        }
        ol { margin-left: 18px; margin-top: 6px; }
        li { margin-bottom: 4px; }
    </style>
</head>
<body>
    <div class="card">
        <div class="header">
            <div class="icon">📱</div>
            <div>
                <h1>USB Screen Mirror</h1>
                <div class="subtitle">Xiaomi 14T ⇄ Realme 5 Pro (OBS Studio Architecture)</div>
            </div>
        </div>

        <div class="status-badge">
            <strong>Laporan Pemeriksaan APK:</strong><br>
            File <code>app-debug.apk</code> belum ada di container karena lingkungan runtime ini adalah <em>Node.js cloud sandbox</em> (tanpa Android SDK/Gradle internal).
        </div>

        <a href="/download" class="btn-download">
            ⬇️ Download ZIP Proyek (${zipSize} KB)
        </a>

        <div class="info-box">
            <h3>Cara Kompilasi Menjadi APK:</h3>
            <ol>
                <li><strong>Di Laptop/PC:</strong> Ekstrak ZIP & buka folder di <em>Android Studio</em> $\rightarrow$ Klik <em>Build</em> $\rightarrow$ <em>Build APK(s)</em>.</li>
                <li><strong>Di GitHub:</strong> Ekstrak & push ke repository GitHub. Proyek telah menyertakan workflow otomatis untuk build APK langsung.</li>
                <li><strong>Langsung di HP:</strong> Gunakan aplikasi <em>Termux</em> di Android (jalankan <code>pkg install openjdk-17</code> lalu <code>./gradlew assembleDebug</code>).</li>
            </ol>
        </div>
    </div>
</body>
</html>`;

    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
    res.end(html);
});

server.listen(PORT, '0.0.0.0', () => {
    console.log(`Server listening on port ${PORT}`);
});
