package com.usbscreenmirror

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.usbscreenmirror.repository.LayerRepository
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

    @Test
    fun readStringFromContext() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("USB Screen Mirror", appName)
    }

    @Test
    fun testLayerRepositoryDefaults() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val repo = LayerRepository(context)
        val defaultLayers = repo.getDefaultLayers()

        assertEquals(2, defaultLayers.size)
        val usbLayer = defaultLayers.find { it.id == "layer_usb_mirror" }
        val cameraLayer = defaultLayers.find { it.id == "layer_host_cam" }

        assertNotNull(usbLayer)
        assertNotNull(cameraLayer)
        assertEquals(0, usbLayer?.zIndex)
        assertEquals(1, cameraLayer?.zIndex)
    }
}
