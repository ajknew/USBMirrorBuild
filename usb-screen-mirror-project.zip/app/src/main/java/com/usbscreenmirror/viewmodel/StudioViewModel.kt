package com.usbscreenmirror.viewmodel

import android.app.Application
import android.view.Surface
import androidx.camera.view.PreviewView
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.viewModelScope
import com.usbscreenmirror.adb.AdbUsbManager
import com.usbscreenmirror.camera.CameraLens
import com.usbscreenmirror.camera.HostCameraManager
import com.usbscreenmirror.decoder.H264Decoder
import com.usbscreenmirror.model.AudioState
import com.usbscreenmirror.model.ConnectionState
import com.usbscreenmirror.model.DiagnosticLog
import com.usbscreenmirror.model.LogLevel
import com.usbscreenmirror.model.StreamingMetrics
import com.usbscreenmirror.model.StudioLayer
import com.usbscreenmirror.repository.LayerRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class ResizeCorner {
    TOP_LEFT,
    TOP_RIGHT,
    BOTTOM_LEFT,
    BOTTOM_RIGHT
}

class StudioViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = LayerRepository(application)

    private val _logs = MutableStateFlow<List<DiagnosticLog>>(emptyList())
    val logs: StateFlow<List<DiagnosticLog>> = _logs.asStateFlow()

    private val _selectedLayerId = MutableStateFlow<String?>("layer_usb_mirror")
    val selectedLayerId: StateFlow<String?> = _selectedLayerId.asStateFlow()

    private val _layers = MutableStateFlow<List<StudioLayer>>(repository.loadLayers())
    val layers: StateFlow<List<StudioLayer>> = _layers.asStateFlow()

    private val _audioState = MutableStateFlow(AudioState())
    val audioState: StateFlow<AudioState> = _audioState.asStateFlow()

    private val _selectedResolution = MutableStateFlow("1280x720")
    val selectedResolution: StateFlow<String> = _selectedResolution.asStateFlow()

    private val _selectedBitrate = MutableStateFlow(4_000_000)
    val selectedBitrate: StateFlow<Int> = _selectedBitrate.asStateFlow()

    val decoder: H264Decoder = H264Decoder { tag, msg, level ->
        addLog(tag, msg, level)
    }

    val cameraManager: HostCameraManager = HostCameraManager(application) { tag, msg, level ->
        addLog(tag, msg, level)
    }

    private val usbManager: AdbUsbManager = AdbUsbManager(
        context = application,
        onLog = { tag, msg, level -> addLog(tag, msg, level) },
        onVideoData = { data -> decoder.feedData(data) }
    )

    val connectionState: StateFlow<ConnectionState> = usbManager.connectionState
    val metrics: StateFlow<StreamingMetrics> = decoder.metrics
    val currentCameraLens: StateFlow<CameraLens> = cameraManager.currentLens

    init {
        addLog("Studio", "USB Screen Mirror Workspace initialized. Single Activity OBS-style engine ready.", LogLevel.SUCCESS)
    }

    fun addLog(tag: String, message: String, level: LogLevel = LogLevel.INFO) {
        val entry = DiagnosticLog(tag = tag, message = message, level = level)
        viewModelScope.launch {
            val currentList = _logs.value.toMutableList()
            if (currentList.size > 200) {
                currentList.removeAt(0)
            }
            currentList.add(entry)
            _logs.value = currentList
        }
    }

    fun setResolution(res: String) {
        _selectedResolution.value = res
        addLog("Studio", "Target streaming resolution set to $res", LogLevel.INFO)
    }

    fun setBitrate(bitrate: Int) {
        _selectedBitrate.value = bitrate
        addLog("Studio", "Target bitrate set to ${bitrate / 1_000_000} Mbps", LogLevel.INFO)
    }

    fun connectUsb() {
        addLog("Studio", "Connect requested. Target: ${_selectedResolution.value} @ ${_selectedBitrate.value / 1_000_000} Mbps", LogLevel.INFO)
        decoder.start()
        usbManager.scanAndConnect(_selectedResolution.value, _selectedBitrate.value)
    }

    fun disconnectUsb() {
        addLog("Studio", "Disconnect requested. Halting stream and releasing USB.", LogLevel.INFO)
        usbManager.disconnect()
        decoder.stop()
    }

    fun attachDecoderSurface(surface: Surface) {
        decoder.attachSurface(surface)
    }

    fun detachDecoderSurface() {
        decoder.detachSurface()
    }

    fun bindHostCamera(previewView: PreviewView, lifecycleOwner: LifecycleOwner) {
        cameraManager.bindToPreviewView(previewView, lifecycleOwner)
    }

    fun switchHostCamera() {
        cameraManager.switchCamera()
    }

    // Layer selection & transforms
    fun selectLayer(id: String?) {
        _selectedLayerId.value = id
    }

    fun updateLayerPosition(id: String, deltaX: Float, deltaY: Float) {
        val updated = _layers.value.map { layer ->
            if (layer.id == id && !layer.isLocked) {
                val newX = (layer.x + deltaX).coerceIn(-0.5f, 1.0f)
                val newY = (layer.y + deltaY).coerceIn(-0.5f, 1.0f)
                layer.copy(x = newX, y = newY)
            } else {
                layer
            }
        }
        _layers.value = updated
        repository.saveLayers(updated)
    }

    fun updateLayerSize(
        id: String,
        deltaW: Float,
        deltaH: Float,
        corner: ResizeCorner,
        canvasAspect: Float
    ) {
        val updated = _layers.value.map { layer ->
            if (layer.id == id && !layer.isLocked) {
                var newW = layer.width
                var newH = layer.height
                var newX = layer.x
                var newY = layer.y

                when (corner) {
                    ResizeCorner.BOTTOM_RIGHT -> {
                        newW = (layer.width + deltaW).coerceIn(0.1f, 1.5f)
                        newH = if (layer.keepAspectRatio) {
                            newW / layer.sourceAspect * canvasAspect
                        } else {
                            (layer.height + deltaH).coerceIn(0.1f, 1.5f)
                        }
                    }
                    ResizeCorner.BOTTOM_LEFT -> {
                        val proposedW = (layer.width - deltaW).coerceIn(0.1f, 1.5f)
                        val shiftX = layer.width - proposedW
                        newW = proposedW
                        newX = layer.x + shiftX
                        newH = if (layer.keepAspectRatio) {
                            newW / layer.sourceAspect * canvasAspect
                        } else {
                            (layer.height + deltaH).coerceIn(0.1f, 1.5f)
                        }
                    }
                    ResizeCorner.TOP_RIGHT -> {
                        newW = (layer.width + deltaW).coerceIn(0.1f, 1.5f)
                        val proposedH = if (layer.keepAspectRatio) {
                            newW / layer.sourceAspect * canvasAspect
                        } else {
                            (layer.height - deltaH).coerceIn(0.1f, 1.5f)
                        }
                        val shiftY = layer.height - proposedH
                        newH = proposedH
                        newY = layer.y + shiftY
                    }
                    ResizeCorner.TOP_LEFT -> {
                        val proposedW = (layer.width - deltaW).coerceIn(0.1f, 1.5f)
                        val shiftX = layer.width - proposedW
                        newW = proposedW
                        newX = layer.x + shiftX

                        val proposedH = if (layer.keepAspectRatio) {
                            newW / layer.sourceAspect * canvasAspect
                        } else {
                            (layer.height - deltaH).coerceIn(0.1f, 1.5f)
                        }
                        val shiftY = layer.height - proposedH
                        newH = proposedH
                        newY = layer.y + shiftY
                    }
                }
                layer.copy(x = newX, y = newY, width = newW, height = newH)
            } else {
                layer
            }
        }
        _layers.value = updated
        repository.saveLayers(updated)
    }

    fun fitLayer(id: String) {
        val updated = _layers.value.map { layer ->
            if (layer.id == id && !layer.isLocked) {
                // Centered with default aspect
                layer.copy(x = 0f, y = 0f, width = 1f, height = 1f)
            } else {
                layer
            }
        }
        _layers.value = updated
        repository.saveLayers(updated)
    }

    fun fillLayer(id: String) {
        val updated = _layers.value.map { layer ->
            if (layer.id == id && !layer.isLocked) {
                layer.copy(x = 0f, y = 0f, width = 1f, height = 1f, keepAspectRatio = false)
            } else {
                layer
            }
        }
        _layers.value = updated
        repository.saveLayers(updated)
    }

    fun resetLayer(id: String) {
        val defaults = repository.getDefaultLayers()
        val defaultLayer = defaults.find { it.id == id } ?: return
        val updated = _layers.value.map { layer ->
            if (layer.id == id) defaultLayer else layer
        }
        _layers.value = updated
        repository.saveLayers(updated)
    }

    fun toggleLayerVisibility(id: String) {
        val updated = _layers.value.map { layer ->
            if (layer.id == id) {
                layer.copy(isVisible = !layer.isVisible)
            } else {
                layer
            }
        }
        _layers.value = updated
        repository.saveLayers(updated)
    }

    fun toggleLayerLock(id: String) {
        val updated = _layers.value.map { layer ->
            if (layer.id == id) {
                layer.copy(isLocked = !layer.isLocked)
            } else {
                layer
            }
        }
        _layers.value = updated
        repository.saveLayers(updated)
    }

    fun toggleKeepAspectRatio(id: String) {
        val updated = _layers.value.map { layer ->
            if (layer.id == id) {
                layer.copy(keepAspectRatio = !layer.keepAspectRatio)
            } else {
                layer
            }
        }
        _layers.value = updated
        repository.saveLayers(updated)
    }

    fun bringLayerForward(id: String) {
        val current = _layers.value
        val index = current.indexOfFirst { it.id == id }
        if (index >= 0 && index < current.size - 1) {
            val mutable = current.toMutableList()
            val temp = mutable[index]
            mutable[index] = mutable[index + 1].copy(zIndex = index)
            mutable[index + 1] = temp.copy(zIndex = index + 1)
            _layers.value = mutable
            repository.saveLayers(mutable)
        }
    }

    fun sendLayerBackward(id: String) {
        val current = _layers.value
        val index = current.indexOfFirst { it.id == id }
        if (index > 0) {
            val mutable = current.toMutableList()
            val temp = mutable[index]
            mutable[index] = mutable[index - 1].copy(zIndex = index)
            mutable[index - 1] = temp.copy(zIndex = index - 1)
            _layers.value = mutable
            repository.saveLayers(mutable)
        }
    }

    // Audio controls
    fun toggleHostMic() {
        val cur = _audioState.value
        _audioState.value = cur.copy(hostMicMuted = !cur.hostMicMuted)
        addLog("Audio", "Host Mic ${if (!cur.hostMicMuted) "MUTED" else "UNMUTED"}", LogLevel.INFO)
    }

    fun setHostMicVolume(vol: Float) {
        _audioState.value = _audioState.value.copy(hostMicVolume = vol)
    }

    override fun onCleared() {
        super.onCleared()
        usbManager.destroy()
        decoder.stop()
        cameraManager.stopCamera()
    }
}
