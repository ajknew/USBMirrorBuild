package com.usbscreenmirror

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.core.content.ContextCompat
import com.usbscreenmirror.model.LogLevel
import com.usbscreenmirror.ui.WorkspaceScreen
import com.usbscreenmirror.ui.theme.UsbScreenMirrorTheme
import com.usbscreenmirror.viewmodel.StudioViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: StudioViewModel by viewModels()

    private val requestPermissionsLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val cameraGranted = permissions[Manifest.permission.CAMERA] ?: false
        val audioGranted = permissions[Manifest.permission.RECORD_AUDIO] ?: false

        if (cameraGranted) {
            viewModel.addLog("Permission", "Izin Kamera diberikan untuk Host Facecam", LogLevel.SUCCESS)
        } else {
            viewModel.addLog("Permission", "Izin Kamera ditolak. Host Facecam tidak dapat menampilkan video.", LogLevel.WARN)
        }

        if (audioGranted) {
            viewModel.addLog("Permission", "Izin Rekam Audio diberikan untuk Host Mic", LogLevel.SUCCESS)
        } else {
            viewModel.addLog("Permission", "Izin Rekam Audio ditolak. Host Mic tidak aktif.", LogLevel.WARN)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Check and request runtime permissions for CameraX & Host Mic
        checkAndRequestPermissions()

        // Handle potential USB device attached intent on launch
        handleUsbIntent(intent)

        setContent {
            UsbScreenMirrorTheme {
                WorkspaceScreen(viewModel = viewModel)
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleUsbIntent(intent)
    }

    private fun handleUsbIntent(intent: Intent?) {
        val action = intent?.action ?: return
        if (action == "android.hardware.usb.action.USB_DEVICE_ATTACHED") {
            viewModel.addLog("USB", "Sistem mendeteksi USB Device Attached. Menyiapkan inisialisasi...", LogLevel.INFO)
            viewModel.connectUsb()
        }
    }

    private fun checkAndRequestPermissions() {
        val permissionsToRequest = mutableListOf<String>()

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            permissionsToRequest.add(Manifest.permission.CAMERA)
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            permissionsToRequest.add(Manifest.permission.RECORD_AUDIO)
        }

        if (permissionsToRequest.isNotEmpty()) {
            requestPermissionsLauncher.launch(permissionsToRequest.toTypedArray())
        }
    }
}
