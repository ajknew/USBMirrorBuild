package com.usbscreenmirror.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Cable
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.usbscreenmirror.model.ConnectionState
import com.usbscreenmirror.model.StreamingMetrics
import com.usbscreenmirror.ui.theme.StudioAccent
import com.usbscreenmirror.ui.theme.StudioLiveRed
import com.usbscreenmirror.ui.theme.StudioSuccess
import com.usbscreenmirror.ui.theme.StudioSurface
import com.usbscreenmirror.ui.theme.StudioTextMuted
import com.usbscreenmirror.ui.theme.StudioTextPrimary
import com.usbscreenmirror.ui.theme.StudioTextSecondary
import com.usbscreenmirror.ui.theme.StudioWarning

@Composable
fun StudioHeader(
    connectionState: ConnectionState,
    metrics: StreamingMetrics,
    activeTab: String,
    onTabSelected: (String) -> Unit,
    onConnectClick: () -> Unit,
    onDisconnectClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        color = StudioSurface,
        modifier = modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Title and branding
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(32.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(StudioAccent.copy(alpha = 0.2f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Cable,
                            contentDescription = "USB OTG",
                            tint = StudioAccent,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = "USB Screen Mirror",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = StudioTextPrimary
                        )
                        Text(
                            text = "Xiaomi 14T (Host) ⇄ Realme 5 Pro (Client)",
                            style = MaterialTheme.typography.labelSmall,
                            color = StudioTextMuted
                        )
                    }
                }

                // Connect / Disconnect button
                val isConnected = connectionState is ConnectionState.Streaming ||
                        connectionState is ConnectionState.Connected ||
                        connectionState is ConnectionState.Connecting

                if (isConnected) {
                    Button(
                        onClick = onDisconnectClick,
                        colors = ButtonDefaults.buttonColors(containerColor = StudioLiveRed),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.testTag("disconnect_button")
                    ) {
                        Icon(Icons.Default.Stop, contentDescription = "Disconnect", modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("DISCONNECT", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                } else {
                    Button(
                        onClick = onConnectClick,
                        colors = ButtonDefaults.buttonColors(containerColor = StudioSuccess),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.testTag("connect_button")
                    ) {
                        Icon(Icons.Default.PlayArrow, contentDescription = "Connect", modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("CONNECT", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            Spacer(modifier = Modifier.size(6.dp))

            // Status bar & Telemetry
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // State Badge
                StateBadge(connectionState = connectionState)

                // LIVE indicator & metrics (if streaming)
                if (connectionState is ConnectionState.Streaming) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        PulsingLiveDot()
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "LIVE",
                            color = StudioLiveRed,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "${metrics.fps.toInt()} FPS",
                            fontFamily = FontFamily.Monospace,
                            color = StudioTextPrimary,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "${metrics.bitrateKbps / 1000f} Mbps",
                            fontFamily = FontFamily.Monospace,
                            color = StudioAccent,
                            fontSize = 11.sp
                        )
                    }
                }

                // Navigation tabs for controls
                Row {
                    HeaderTabButton(
                        icon = Icons.Default.Layers,
                        title = "Layers",
                        isSelected = activeTab == "layers",
                        onClick = { onTabSelected("layers") }
                    )
                    HeaderTabButton(
                        icon = Icons.Default.Mic,
                        title = "Audio",
                        isSelected = activeTab == "audio",
                        onClick = { onTabSelected("audio") }
                    )
                    HeaderTabButton(
                        icon = Icons.Default.Info,
                        title = "Logs",
                        isSelected = activeTab == "logs",
                        onClick = { onTabSelected("logs") }
                    )
                }
            }
        }
    }
}

@Composable
private fun StateBadge(connectionState: ConnectionState) {
    val (bgColor, textColor, label) = when (connectionState) {
        is ConnectionState.Disconnected -> Triple(Color(0xFF272A36), StudioTextMuted, "DISCONNECTED")
        is ConnectionState.DeviceDetected -> Triple(StudioAccent.copy(alpha = 0.2f), StudioAccent, "USB DETECTED")
        is ConnectionState.PermissionRequired -> Triple(StudioWarning.copy(alpha = 0.2f), StudioWarning, "PERMISSION NEEDED")
        is ConnectionState.AdbAuthentication -> Triple(Color(0xFF8B5CF6).copy(alpha = 0.2f), Color(0xFFA78BFA), "ADB AUTH PROMPT")
        is ConnectionState.Connecting -> Triple(StudioWarning.copy(alpha = 0.2f), StudioWarning, "CONNECTING...")
        is ConnectionState.Connected -> Triple(StudioSuccess.copy(alpha = 0.2f), StudioSuccess, "CONNECTED")
        is ConnectionState.Streaming -> Triple(StudioSuccess.copy(alpha = 0.25f), StudioSuccess, "STREAMING")
        is ConnectionState.DecoderError -> Triple(StudioLiveRed.copy(alpha = 0.2f), StudioLiveRed, "DECODER ERROR")
        is ConnectionState.UsbDisconnected -> Triple(Color(0xFF374151), StudioTextMuted, "USB DISCONNECTED")
        is ConnectionState.Error -> Triple(StudioLiveRed.copy(alpha = 0.2f), StudioLiveRed, "ERROR")
    }

    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .clip(RoundedCornerShape(4.dp))
            .background(bgColor)
            .padding(horizontal = 6.dp, vertical = 2.dp)
    ) {
        Box(
            modifier = Modifier
                .size(6.dp)
                .clip(CircleShape)
                .background(textColor)
        )
        Spacer(modifier = Modifier.width(4.dp))
        Text(
            text = label,
            color = textColor,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
private fun PulsingLiveDot() {
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val alpha by infiniteTransition.animateFloat(
        initialValue = 0.3f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(600),
            repeatMode = RepeatMode.Reverse
        ),
        label = "alpha"
    )

    Box(
        modifier = Modifier
            .size(8.dp)
            .alpha(alpha)
            .clip(CircleShape)
            .background(StudioLiveRed)
    )
}

@Composable
private fun HeaderTabButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    IconButton(
        onClick = onClick,
        modifier = Modifier.size(36.dp)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = title,
            tint = if (isSelected) StudioAccent else StudioTextSecondary,
            modifier = Modifier.size(18.dp)
        )
    }
}
