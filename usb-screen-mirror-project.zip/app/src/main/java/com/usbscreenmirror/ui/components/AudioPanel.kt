package com.usbscreenmirror.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.VolumeDown
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.usbscreenmirror.model.AudioState
import com.usbscreenmirror.ui.theme.StudioAccent
import com.usbscreenmirror.ui.theme.StudioLiveRed
import com.usbscreenmirror.ui.theme.StudioSuccess
import com.usbscreenmirror.ui.theme.StudioSurface
import com.usbscreenmirror.ui.theme.StudioSurfaceVariant
import com.usbscreenmirror.ui.theme.StudioTextMuted
import com.usbscreenmirror.ui.theme.StudioTextPrimary
import com.usbscreenmirror.ui.theme.StudioWarning
import com.usbscreenmirror.viewmodel.StudioViewModel

@Composable
fun AudioPanel(
    viewModel: StudioViewModel,
    audioState: AudioState,
    modifier: Modifier = Modifier
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = StudioSurface),
        shape = RoundedCornerShape(12.dp),
        modifier = modifier
            .fillMaxWidth()
            .padding(8.dp)
            .testTag("audio_panel")
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "AUDIO MIXER & AUDIT",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = StudioTextPrimary
                )
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(StudioAccent.copy(alpha = 0.2f))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text("AUDIT STATUS", color = StudioAccent, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Technical Audit Card
            Card(
                colors = CardDefaults.cardColors(containerColor = StudioSurfaceVariant),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Info,
                            contentDescription = "Technical Audit",
                            tint = StudioWarning,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Laporan Audit Kelayakan Teknis Audio Client:",
                            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                            color = StudioWarning
                        )
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    Text(
                        text = "1. Biner bawaan Android AOSP (/system/bin/screenrecord) hanya memproses aliran video H.264 melalui SurfaceFlinger dan TIDAK mendukung penangkapan audio sistem.\n" +
                                "2. Android membatasi pengambilan internal audio melalui AudioPlaybackCapture API yang mewajibkan izin MediaProjection dan pemasangan APK Client pada Realme 5 Pro.\n" +
                                "3. Sesuai batasan sistem (tanpa memasang aplikasi pada Client), audio internal Client tidak dapat dialirkan hanya lewat biner screenrecord.\n" +
                                "4. Solusi hardware yang dianjurkan untuk live audio: Gunakan kabel aux/jack 3.5mm atau USB Audio splitter langsung dari Realme 5 Pro ke input host.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = StudioTextMuted,
                        fontSize = 11.sp,
                        lineHeight = 16.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Host Microphone Controls (Actual Real Feature)
            Text(
                text = "Host Microphone (Xiaomi 14T Voiceover / Commentary)",
                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                color = StudioTextPrimary
            )

            Spacer(modifier = Modifier.height(6.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Button(
                    onClick = { viewModel.toggleHostMic() },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (audioState.hostMicMuted) StudioLiveRed else StudioSuccess
                    ),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(
                        imageVector = if (audioState.hostMicMuted) Icons.Default.MicOff else Icons.Default.Mic,
                        contentDescription = "Mic Toggle",
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (audioState.hostMicMuted) "MIC MUTED" else "MIC AKTIF",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Text(
                    text = "${(audioState.hostMicVolume * 100).toInt()}%",
                    color = StudioAccent,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.VolumeDown, contentDescription = "Low", tint = StudioTextMuted, modifier = Modifier.size(16.dp))
                Slider(
                    value = audioState.hostMicVolume,
                    onValueChange = { viewModel.setHostMicVolume(it) },
                    valueRange = 0f..1f,
                    colors = SliderDefaults.colors(
                        thumbColor = StudioAccent,
                        activeTrackColor = StudioAccent,
                        inactiveTrackColor = StudioSurfaceVariant
                    ),
                    modifier = Modifier.weight(1f).padding(horizontal = 8.dp)
                )
                Icon(Icons.Default.VolumeUp, contentDescription = "High", tint = StudioTextMuted, modifier = Modifier.size(16.dp))
            }
        }
    }
}
