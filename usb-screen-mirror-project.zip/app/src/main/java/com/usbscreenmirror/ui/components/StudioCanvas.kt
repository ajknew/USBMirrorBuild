package com.usbscreenmirror.ui.components

import android.graphics.SurfaceTexture
import android.view.Surface
import android.view.TextureView
import androidx.camera.view.PreviewView
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Tv
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.usbscreenmirror.model.ConnectionState
import com.usbscreenmirror.model.LayerType
import com.usbscreenmirror.model.StudioLayer
import com.usbscreenmirror.ui.theme.StudioAccent
import com.usbscreenmirror.ui.theme.StudioCanvasBg
import com.usbscreenmirror.ui.theme.StudioSelectionHandle
import com.usbscreenmirror.ui.theme.StudioSurfaceVariant
import com.usbscreenmirror.ui.theme.StudioTextMuted
import com.usbscreenmirror.ui.theme.StudioWarning
import com.usbscreenmirror.viewmodel.ResizeCorner
import com.usbscreenmirror.viewmodel.StudioViewModel
import kotlin.math.roundToInt

@Composable
fun StudioCanvas(
    viewModel: StudioViewModel,
    layers: List<StudioLayer>,
    selectedLayerId: String?,
    connectionState: ConnectionState,
    modifier: Modifier = Modifier
) {
    val lifecycleOwner = LocalLifecycleOwner.current

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(StudioCanvasBg)
            .clickable { viewModel.selectLayer(null) }
            .testTag("studio_canvas"),
        contentAlignment = Alignment.Center
    ) {
        // Enforce 16:9 Canvas Work Area
        BoxWithConstraints(
            modifier = Modifier
                .fillMaxSize()
                .padding(4.dp)
                .clipToBounds()
        ) {
            val canvasWidthPx = constraints.maxWidth.toFloat().coerceAtLeast(1f)
            val canvasHeightPx = constraints.maxHeight.toFloat().coerceAtLeast(1f)
            val canvasAspect = canvasWidthPx / canvasHeightPx

            // Render visible layers sorted by zIndex
            val sortedLayers = layers.filter { it.isVisible }.sortedBy { it.zIndex }

            for (layer in sortedLayers) {
                val isSelected = layer.id == selectedLayerId

                val layerXPx = layer.x * canvasWidthPx
                val layerYPx = layer.y * canvasHeightPx
                val layerWPx = (layer.width * canvasWidthPx).coerceAtLeast(40f)
                val layerHPx = (layer.height * canvasHeightPx).coerceAtLeast(40f)

                val density = LocalDensity.current
                val layerWidthDp = with(density) { layerWPx.toDp() }
                val layerHeightDp = with(density) { layerHPx.toDp() }

                Box(
                    modifier = Modifier
                        .offset { IntOffset(layerXPx.roundToInt(), layerYPx.roundToInt()) }
                        .size(width = layerWidthDp, height = layerHeightDp)
                        .clipToBounds()
                        .clickable { viewModel.selectLayer(layer.id) }
                        .then(
                            if (!layer.isLocked) {
                                Modifier.pointerInput(layer.id) {
                                    detectDragGestures { change, dragAmount ->
                                        change.consume()
                                        val deltaXFraction = dragAmount.x / canvasWidthPx
                                        val deltaYFraction = dragAmount.y / canvasHeightPx
                                        viewModel.updateLayerPosition(layer.id, deltaXFraction, deltaYFraction)
                                    }
                                }
                            } else {
                                Modifier
                            }
                        )
                ) {
                    // Visual Source
                    when (layer.type) {
                        LayerType.USB_MIRROR -> {
                            Box(modifier = Modifier.fillMaxSize()) {
                                AndroidView(
                                    factory = { ctx ->
                                        TextureView(ctx).apply {
                                            surfaceTextureListener = object : TextureView.SurfaceTextureListener {
                                                override fun onSurfaceTextureAvailable(st: SurfaceTexture, w: Int, h: Int) {
                                                    viewModel.attachDecoderSurface(Surface(st))
                                                }
                                                override fun onSurfaceTextureSizeChanged(st: SurfaceTexture, w: Int, h: Int) {}
                                                override fun onSurfaceTextureDestroyed(st: SurfaceTexture): Boolean {
                                                    viewModel.detachDecoderSurface()
                                                    return true
                                                }
                                                override fun onSurfaceTextureUpdated(st: SurfaceTexture) {}
                                            }
                                        }
                                    },
                                    modifier = Modifier.fillMaxSize()
                                )

                                // Placeholder overlay if not streaming yet
                                if (connectionState !is ConnectionState.Streaming) {
                                    Box(
                                        modifier = Modifier
                                            .fillMaxSize()
                                            .background(StudioSurfaceVariant.copy(alpha = 0.85f)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = when (connectionState) {
                                                is ConnectionState.AdbAuthentication -> "Menunggu Otorisasi Kunci ADB pada Client..."
                                                is ConnectionState.Connecting -> "Menghubungkan ke Client..."
                                                is ConnectionState.Connected -> "Siap. Menyiapkan Video H.264..."
                                                else -> "USB Mirroring (Tekan CONNECT untuk memulai)"
                                            },
                                            color = StudioTextMuted,
                                            fontSize = 11.sp
                                        )
                                    }
                                }
                            }
                        }
                        LayerType.HOST_CAMERA -> {
                            Box(modifier = Modifier.fillMaxSize()) {
                                AndroidView(
                                    factory = { ctx ->
                                        PreviewView(ctx).apply {
                                            scaleType = PreviewView.ScaleType.FILL_CENTER
                                            viewModel.bindHostCamera(this, lifecycleOwner)
                                        }
                                    },
                                    modifier = Modifier.fillMaxSize()
                                )
                            }
                        }
                    }

                    // Selection Bounding Box & Handles
                    if (isSelected) {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .border(1.5.dp, StudioAccent)
                        )

                        // Lock indicator badge
                        if (layer.isLocked) {
                            Box(
                                modifier = Modifier
                                    .align(Alignment.TopEnd)
                                    .padding(4.dp)
                                    .size(20.dp)
                                    .clip(CircleShape)
                                    .background(StudioWarning),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Lock,
                                    contentDescription = "Locked",
                                    tint = Color.Black,
                                    modifier = Modifier.size(12.dp)
                                )
                            }
                        } else {
                            // 4 Corner Resize Handles
                            CornerHandle(
                                alignment = Alignment.TopStart,
                                onDrag = { dx, dy ->
                                    val dW = -dx / canvasWidthPx
                                    val dH = -dy / canvasHeightPx
                                    viewModel.updateLayerSize(layer.id, dW, dH, ResizeCorner.TOP_LEFT, canvasAspect)
                                }
                            )
                            CornerHandle(
                                alignment = Alignment.TopEnd,
                                onDrag = { dx, dy ->
                                    val dW = dx / canvasWidthPx
                                    val dH = -dy / canvasHeightPx
                                    viewModel.updateLayerSize(layer.id, dW, dH, ResizeCorner.TOP_RIGHT, canvasAspect)
                                }
                            )
                            CornerHandle(
                                alignment = Alignment.BottomStart,
                                onDrag = { dx, dy ->
                                    val dW = -dx / canvasWidthPx
                                    val dH = dy / canvasHeightPx
                                    viewModel.updateLayerSize(layer.id, dW, dH, ResizeCorner.BOTTOM_LEFT, canvasAspect)
                                }
                            )
                            CornerHandle(
                                alignment = Alignment.BottomEnd,
                                onDrag = { dx, dy ->
                                    val dW = dx / canvasWidthPx
                                    val dH = dy / canvasHeightPx
                                    viewModel.updateLayerSize(layer.id, dW, dH, ResizeCorner.BOTTOM_RIGHT, canvasAspect)
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun CornerHandle(
    alignment: Alignment,
    onDrag: (Float, Float) -> Unit
) {
    Box(
        modifier = Modifier
            .size(48.dp) // Accessibility compliant touch target
            .offset(
                x = if (alignment == Alignment.TopStart || alignment == Alignment.BottomStart) (-14).dp else 14.dp,
                y = if (alignment == Alignment.TopStart || alignment == Alignment.TopEnd) (-14).dp else 14.dp
            )
            .pointerInput(alignment) {
                detectDragGestures { change, dragAmount ->
                    change.consume()
                    onDrag(dragAmount.x, dragAmount.y)
                }
            },
        contentAlignment = Alignment.Center
    ) {
        Box(
            modifier = Modifier
                .size(12.dp)
                .clip(CircleShape)
                .background(StudioSelectionHandle)
                .border(1.dp, Color.White, CircleShape)
        )
    }
}
