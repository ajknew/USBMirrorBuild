package com.usbscreenmirror.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val StudioColorScheme = darkColorScheme(
    primary = StudioAccent,
    onPrimary = StudioDarkBg,
    primaryContainer = StudioSurfaceVariant,
    onPrimaryContainer = StudioTextPrimary,
    secondary = StudioSuccess,
    onSecondary = StudioDarkBg,
    background = StudioDarkBg,
    onBackground = StudioTextPrimary,
    surface = StudioSurface,
    onSurface = StudioTextPrimary,
    surfaceVariant = StudioSurfaceVariant,
    onSurfaceVariant = StudioTextSecondary,
    error = StudioLiveRed,
    onError = StudioTextPrimary
)

@Composable
fun UsbScreenMirrorTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = StudioColorScheme,
        typography = Typography,
        content = content
    )
}
