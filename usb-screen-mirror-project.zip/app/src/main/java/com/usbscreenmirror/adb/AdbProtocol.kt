package com.usbscreenmirror.adb

import java.nio.ByteBuffer
import java.nio.ByteOrder

object AdbProtocol {
    const val CMD_CNXN = 0x4e584e43 // "CNXN"
    const val CMD_AUTH = 0x48545541 // "AUTH"
    const val CMD_OPEN = 0x4e45504f // "OPEN"
    const val CMD_OKAY = 0x59414b4f // "OKAY"
    const val CMD_CLSE = 0x45534c43 // "CLSE"
    const val CMD_WRTE = 0x45545257 // "WRTE"

    const val AUTH_TYPE_TOKEN = 1
    const val AUTH_TYPE_SIGNATURE = 2
    const val AUTH_TYPE_RSAPUBLICKEY = 3

    const val ADB_VERSION = 0x01000000
    const val MAX_DATA = 4096

    fun commandToString(cmd: Int): String {
        return when (cmd) {
            CMD_CNXN -> "CNXN"
            CMD_AUTH -> "AUTH"
            CMD_OPEN -> "OPEN"
            CMD_OKAY -> "OKAY"
            CMD_CLSE -> "CLSE"
            CMD_WRTE -> "WRTE"
            else -> "UNKNOWN(0x${Integer.toHexString(cmd)})"
        }
    }

    data class Message(
        val command: Int,
        val arg0: Int,
        val arg1: Int,
        val payload: ByteArray = ByteArray(0)
    ) {
        val dataLength: Int get() = payload.size
        val dataCheck: Int get() = calculateChecksum(payload)
        val magic: Int get() = command xor -0x1 // 0xFFFFFFFF

        fun serialize(): ByteArray {
            val buffer = ByteBuffer.allocate(24 + payload.size).order(ByteOrder.LITTLE_ENDIAN)
            buffer.putInt(command)
            buffer.putInt(arg0)
            buffer.putInt(arg1)
            buffer.putInt(dataLength)
            buffer.putInt(dataCheck)
            buffer.putInt(magic)
            if (payload.isNotEmpty()) {
                buffer.put(payload)
            }
            return buffer.array()
        }

        override fun equals(other: Any?): Boolean {
            if (this === other) return true
            if (other !is Message) return false
            if (command != other.command) return false
            if (arg0 != other.arg0) return false
            if (arg1 != other.arg1) return false
            if (!payload.contentEquals(other.payload)) return false
            return true
        }

        override fun hashCode(): Int {
            var result = command
            result = 31 * result + arg0
            result = 31 * result + arg1
            result = 31 * result + payload.contentHashCode()
            return result
        }
    }

    data class Header(
        val command: Int,
        val arg0: Int,
        val arg1: Int,
        val dataLength: Int,
        val dataCheck: Int,
        val magic: Int
    ) {
        val isValid: Boolean get() = (command xor -0x1) == magic
    }

    fun parseHeader(bytes: ByteArray): Header {
        require(bytes.size >= 24) { "Header bytes must be at least 24 bytes, got ${bytes.size}" }
        val buffer = ByteBuffer.wrap(bytes, 0, 24).order(ByteOrder.LITTLE_ENDIAN)
        return Header(
            command = buffer.int,
            arg0 = buffer.int,
            arg1 = buffer.int,
            dataLength = buffer.int,
            dataCheck = buffer.int,
            magic = buffer.int
        )
    }

    fun calculateChecksum(data: ByteArray): Int {
        var sum = 0
        for (b in data) {
            sum += (b.toInt() and 0xFF)
        }
        return sum
    }

    fun createConnectMessage(banner: String = "host::UsbScreenMirror"): Message {
        val payload = banner.toByteArray(Charsets.UTF_8)
        return Message(
            command = CMD_CNXN,
            arg0 = ADB_VERSION,
            arg1 = MAX_DATA,
            payload = payload
        )
    }

    fun createAuthSignatureMessage(signature: ByteArray): Message {
        return Message(
            command = CMD_AUTH,
            arg0 = AUTH_TYPE_SIGNATURE,
            arg1 = 0,
            payload = signature
        )
    }

    fun createAuthPublicKeyMessage(publicKey: ByteArray): Message {
        return Message(
            command = CMD_AUTH,
            arg0 = AUTH_TYPE_RSAPUBLICKEY,
            arg1 = 0,
            payload = publicKey
        )
    }

    fun createOpenMessage(localId: Int, destination: String): Message {
        val destBytes = "$destination\u0000".toByteArray(Charsets.UTF_8)
        return Message(
            command = CMD_OPEN,
            arg0 = localId,
            arg1 = 0,
            payload = destBytes
        )
    }

    fun createOkayMessage(localId: Int, remoteId: Int): Message {
        return Message(
            command = CMD_OKAY,
            arg0 = localId,
            arg1 = remoteId,
            payload = ByteArray(0)
        )
    }

    fun createCloseMessage(localId: Int, remoteId: Int): Message {
        return Message(
            command = CMD_CLSE,
            arg0 = localId,
            arg1 = remoteId,
            payload = ByteArray(0)
        )
    }
}
