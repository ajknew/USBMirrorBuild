package com.usbscreenmirror.adb

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.usb.UsbConstants
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbDeviceConnection
import android.hardware.usb.UsbEndpoint
import android.hardware.usb.UsbInterface
import android.hardware.usb.UsbManager
import android.os.Build
import com.usbscreenmirror.model.ConnectionState
import com.usbscreenmirror.model.LogLevel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.IOException
import java.util.concurrent.atomic.AtomicBoolean

class AdbUsbManager(
    private val context: Context,
    private val onLog: (String, String, LogLevel) -> Unit,
    private val onVideoData: (ByteArray) -> Unit
) {
    companion object {
        const val ACTION_USB_PERMISSION = "com.usbscreenmirror.USB_PERMISSION"
        private const val TAG = "AdbUsbManager"
        private const val ADB_CLASS = 0xFF
        private const val ADB_SUBCLASS = 0x42
        private const val ADB_PROTOCOL = 0x01
    }

    private val usbManager = context.getSystemService(Context.USB_SERVICE) as UsbManager
    private val scope = CoroutineScope(Dispatchers.IO + Job())
    private var adbKeyPair = AdbKeyPair.getOrCreate(context)

    private val _connectionState = MutableStateFlow<ConnectionState>(ConnectionState.Disconnected)
    val connectionState: StateFlow<ConnectionState> = _connectionState.asStateFlow()

    private var usbConnection: UsbDeviceConnection? = null
    private var adbInterface: UsbInterface? = null
    private var inEndpoint: UsbEndpoint? = null
    private var outEndpoint: UsbEndpoint? = null
    private var workerJob: Job? = null
    private val isRunning = AtomicBoolean(false)

    private var localStreamId = 1
    private var remoteStreamId = 0

    private val usbReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val action = intent?.action ?: return
            when (action) {
                ACTION_USB_PERMISSION -> {
                    synchronized(this) {
                        val device: UsbDevice? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                            intent.getParcelableExtra(UsbManager.EXTRA_DEVICE, UsbDevice::class.java)
                        } else {
                            @Suppress("DEPRECATION")
                            intent.getParcelableExtra(UsbManager.EXTRA_DEVICE)
                        }
                        val granted = intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false)
                        if (granted && device != null) {
                            onLog(TAG, "USB Permission granted for ${device.deviceName}", LogLevel.SUCCESS)
                            startAdbSession(device)
                        } else {
                            onLog(TAG, "USB Permission denied by user", LogLevel.ERROR)
                            _connectionState.value = ConnectionState.Error("USB Permission denied")
                        }
                    }
                }
                UsbManager.ACTION_USB_DEVICE_DETACHED -> {
                    val device: UsbDevice? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        intent.getParcelableExtra(UsbManager.EXTRA_DEVICE, UsbDevice::class.java)
                    } else {
                        @Suppress("DEPRECATION")
                        intent.getParcelableExtra(UsbManager.EXTRA_DEVICE)
                    }
                    onLog(TAG, "USB Device detached: ${device?.deviceName ?: "unknown"}", LogLevel.WARN)
                    disconnect()
                    _connectionState.value = ConnectionState.UsbDisconnected
                }
            }
        }
    }

    init {
        val filter = IntentFilter().apply {
            addAction(ACTION_USB_PERMISSION)
            addAction(UsbManager.ACTION_USB_DEVICE_DETACHED)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            context.registerReceiver(usbReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            context.registerReceiver(usbReceiver, filter)
        }
    }

    fun scanAndConnect(resolution: String = "1280x720", bitrate: Int = 4000000) {
        if (isRunning.get()) {
            onLog(TAG, "Connection session already running", LogLevel.WARN)
            return
        }

        onLog(TAG, "Scanning for USB OTG connected devices...", LogLevel.INFO)
        val deviceList = usbManager.deviceList
        if (deviceList.isEmpty()) {
            onLog(TAG, "No USB device detected. Please connect Client device via USB OTG cable.", LogLevel.WARN)
            _connectionState.value = ConnectionState.Disconnected
            return
        }

        // Search for device with ADB interface
        var targetDevice: UsbDevice? = null
        for ((_, device) in deviceList) {
            if (findAdbInterface(device) != null) {
                targetDevice = device
                break
            }
        }

        // If no strict ADB class match, take first device with bulk IN/OUT endpoints
        if (targetDevice == null) {
            for ((_, device) in deviceList) {
                if (findGenericBulkInterface(device) != null) {
                    targetDevice = device
                    break
                }
            }
        }

        if (targetDevice == null) {
            val firstDev = deviceList.values.first()
            onLog(TAG, "Device detected (${firstDev.deviceName}, VID: ${firstDev.vendorId}, PID: ${firstDev.productId}) but no ADB endpoints found. Ensure USB Debugging is ON on Client.", LogLevel.WARN)
            _connectionState.value = ConnectionState.DeviceDetected(
                firstDev.deviceName,
                firstDev.vendorId,
                firstDev.productId
            )
            return
        }

        val dev = targetDevice
        _connectionState.value = ConnectionState.DeviceDetected(dev.deviceName, dev.vendorId, dev.productId)
        onLog(TAG, "Target device identified: ${dev.deviceName} (VID: 0x${Integer.toHexString(dev.vendorId)}, PID: 0x${Integer.toHexString(dev.productId)})", LogLevel.INFO)

        if (!usbManager.hasPermission(dev)) {
            onLog(TAG, "Requesting USB host permission from system...", LogLevel.INFO)
            _connectionState.value = ConnectionState.PermissionRequired
            val flags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                PendingIntent.FLAG_MUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            } else {
                PendingIntent.FLAG_UPDATE_CURRENT
            }
            val permissionIntent = PendingIntent.getBroadcast(
                context,
                0,
                Intent(ACTION_USB_PERMISSION),
                flags
            )
            usbManager.requestPermission(dev, permissionIntent)
        } else {
            startAdbSession(dev, resolution, bitrate)
        }
    }

    private fun findAdbInterface(device: UsbDevice): UsbInterface? {
        for (i in 0 until device.interfaceCount) {
            val iface = device.getInterface(i)
            if (iface.interfaceClass == ADB_CLASS &&
                iface.interfaceSubclass == ADB_SUBCLASS &&
                iface.interfaceProtocol == ADB_PROTOCOL
            ) {
                return iface
            }
        }
        return null
    }

    private fun findGenericBulkInterface(device: UsbDevice): UsbInterface? {
        for (i in 0 until device.interfaceCount) {
            val iface = device.getInterface(i)
            var hasIn = false
            var hasOut = false
            for (j in 0 until iface.endpointCount) {
                val ep = iface.getEndpoint(j)
                if (ep.type == UsbConstants.USB_ENDPOINT_XFER_BULK) {
                    if (ep.direction == UsbConstants.USB_DIR_IN) hasIn = true
                    if (ep.direction == UsbConstants.USB_DIR_OUT) hasOut = true
                }
            }
            if (hasIn && hasOut) return iface
        }
        return null
    }

    private fun startAdbSession(
        device: UsbDevice,
        resolution: String = "1280x720",
        bitrate: Int = 4000000
    ) {
        workerJob?.cancel()
        workerJob = scope.launch {
            try {
                isRunning.set(true)
                _connectionState.value = ConnectionState.Connecting
                onLog(TAG, "Opening USB device connection...", LogLevel.INFO)

                val conn = usbManager.openDevice(device)
                    ?: throw IOException("Failed to open USB device connection")
                usbConnection = conn

                val iface = findAdbInterface(device) ?: findGenericBulkInterface(device)
                    ?: throw IOException("No suitable USB bulk interface found on device")
                adbInterface = iface

                if (!conn.claimInterface(iface, true)) {
                    throw IOException("Could not claim USB interface")
                }

                // Locate IN and OUT endpoints
                var inEp: UsbEndpoint? = null
                var outEp: UsbEndpoint? = null
                for (i in 0 until iface.endpointCount) {
                    val ep = iface.getEndpoint(i)
                    if (ep.type == UsbConstants.USB_ENDPOINT_XFER_BULK) {
                        if (ep.direction == UsbConstants.USB_DIR_IN) inEp = ep
                        else if (ep.direction == UsbConstants.USB_DIR_OUT) outEp = ep
                    }
                }

                if (inEp == null || outEp == null) {
                    throw IOException("Missing Bulk IN or OUT USB endpoint")
                }
                inEndpoint = inEp
                outEndpoint = outEp

                onLog(TAG, "USB Endpoints ready. IN: ${inEp.address}, OUT: ${outEp.address}", LogLevel.SUCCESS)

                // Handshake step 1: Send CNXN
                val cnxnMsg = AdbProtocol.createConnectMessage("host::UsbScreenMirror")
                writeMessage(conn, outEp, cnxnMsg)
                onLog(TAG, "Sent ADB CNXN packet", LogLevel.INFO)

                // Read responses
                var isAuthorized = false
                while (isActive && isRunning.get() && !isAuthorized) {
                    val resp = readMessage(conn, inEp)
                    onLog(TAG, "Received ADB ${AdbProtocol.commandToString(resp.command)} (arg0=${resp.arg0}, len=${resp.dataLength})", LogLevel.INFO)

                    when (resp.command) {
                        AdbProtocol.CMD_AUTH -> {
                            if (resp.arg0 == AdbProtocol.AUTH_TYPE_TOKEN) {
                                // Try signing first
                                onLog(TAG, "Received token challenge, attempting RSA signature...", LogLevel.INFO)
                                val signature = adbKeyPair.signToken(resp.payload)
                                writeMessage(conn, outEp, AdbProtocol.createAuthSignatureMessage(signature))

                                // Check next message; if another AUTH received, client needs public key
                                val authNext = readMessage(conn, inEp)
                                if (authNext.command == AdbProtocol.CMD_AUTH && authNext.arg0 == AdbProtocol.AUTH_TYPE_TOKEN) {
                                    onLog(TAG, "Device requested RSA Public Key. Presenting authorization prompt on Client...", LogLevel.WARN)
                                    _connectionState.value = ConnectionState.AdbAuthentication("Izinkan USB Debugging pada layar HP Client (Centang 'Selalu izinkan').")
                                    val pubKeyMsg = AdbProtocol.createAuthPublicKeyMessage(adbKeyPair.adbPublicKeyPayload)
                                    writeMessage(conn, outEp, pubKeyMsg)
                                } else if (authNext.command == AdbProtocol.CMD_CNXN) {
                                    val banner = String(authNext.payload, Charsets.UTF_8).trim()
                                    onLog(TAG, "ADB Connection Established! Client: $banner", LogLevel.SUCCESS)
                                    _connectionState.value = ConnectionState.Connected(banner)
                                    isAuthorized = true
                                }
                            }
                        }
                        AdbProtocol.CMD_CNXN -> {
                            val banner = String(resp.payload, Charsets.UTF_8).trim()
                            onLog(TAG, "ADB Connected directly! Client: $banner", LogLevel.SUCCESS)
                            _connectionState.value = ConnectionState.Connected(banner)
                            isAuthorized = true
                        }
                        else -> {
                            onLog(TAG, "Unexpected message during auth: ${AdbProtocol.commandToString(resp.command)}", LogLevel.WARN)
                        }
                    }
                }

                if (!isAuthorized) return@launch

                // Open streaming exec channel
                localStreamId = 1
                val execCommand = "exec:screenrecord --output-format=h264 --size $resolution --bit-rate $bitrate -"
                onLog(TAG, "Requesting video stream: $execCommand", LogLevel.INFO)
                writeMessage(conn, outEp, AdbProtocol.createOpenMessage(localStreamId, execCommand))

                // Wait for OKAY
                val openResp = readMessage(conn, inEp)
                if (openResp.command != AdbProtocol.CMD_OKAY) {
                    throw IOException("Failed to open stream channel, expected OKAY but got ${AdbProtocol.commandToString(openResp.command)}")
                }
                remoteStreamId = openResp.arg0
                onLog(TAG, "ADB Channel opened successfully (local: $localStreamId, remote: $remoteStreamId)", LogLevel.SUCCESS)
                _connectionState.value = ConnectionState.Streaming(resolution)

                // Continuous stream read loop
                while (isActive && isRunning.get()) {
                    val streamMsg = readMessage(conn, inEp)
                    when (streamMsg.command) {
                        AdbProtocol.CMD_WRTE -> {
                            // Acknowledge immediately to keep ADB pipe flowing
                            writeMessage(conn, outEp, AdbProtocol.createOkayMessage(localStreamId, remoteStreamId))

                            if (streamMsg.payload.isNotEmpty()) {
                                onVideoData(streamMsg.payload)
                            }
                        }
                        AdbProtocol.CMD_CLSE -> {
                            onLog(TAG, "Client closed ADB stream channel", LogLevel.WARN)
                            break
                        }
                        AdbProtocol.CMD_OKAY -> {
                            // Keep alive or channel ACK
                        }
                    }
                }
            } catch (e: Exception) {
                if (isRunning.get()) {
                    onLog(TAG, "ADB Session error: ${e.message}", LogLevel.ERROR)
                    _connectionState.value = ConnectionState.Error(e.message ?: "ADB connection error")
                }
            } finally {
                cleanup()
            }
        }
    }

    private fun writeMessage(conn: UsbDeviceConnection, ep: UsbEndpoint, message: AdbProtocol.Message) {
        val bytes = message.serialize()
        var offset = 0
        while (offset < bytes.size && isRunning.get()) {
            val length = minOf(bytes.size - offset, ep.maxPacketSize.coerceAtLeast(64))
            val written = conn.bulkTransfer(ep, bytes, offset, length, 3000)
            if (written < 0) {
                throw IOException("USB bulkTransfer OUT failed (returned $written)")
            }
            offset += written
        }
    }

    private fun readMessage(conn: UsbDeviceConnection, ep: UsbEndpoint): AdbProtocol.Message {
        // Read 24-byte header
        val headerBytes = ByteArray(24)
        var readHeader = 0
        while (readHeader < 24 && isRunning.get()) {
            val count = conn.bulkTransfer(ep, headerBytes, readHeader, 24 - readHeader, 5000)
            if (count < 0) {
                throw IOException("USB bulkTransfer IN header failed (returned $count)")
            }
            readHeader += count
        }

        val header = AdbProtocol.parseHeader(headerBytes)
        if (!header.isValid) {
            throw IOException("Corrupt ADB packet header received (command: ${header.command}, magic: ${header.magic})")
        }

        val payload = if (header.dataLength > 0) {
            val body = ByteArray(header.dataLength)
            var readBody = 0
            while (readBody < header.dataLength && isRunning.get()) {
                val chunkSize = minOf(header.dataLength - readBody, 16384)
                val count = conn.bulkTransfer(ep, body, readBody, chunkSize, 5000)
                if (count < 0) {
                    throw IOException("USB bulkTransfer IN payload failed (returned $count)")
                }
                readBody += count
            }
            body
        } else {
            ByteArray(0)
        }

        return AdbProtocol.Message(
            command = header.command,
            arg0 = header.arg0,
            arg1 = header.arg1,
            payload = payload
        )
    }

    fun disconnect() {
        if (!isRunning.getAndSet(false)) return
        onLog(TAG, "Disconnecting ADB and releasing USB resources...", LogLevel.INFO)

        scope.launch {
            try {
                val conn = usbConnection
                val outEp = outEndpoint
                if (conn != null && outEp != null && remoteStreamId != 0) {
                    try {
                        val closeMsg = AdbProtocol.createCloseMessage(localStreamId, remoteStreamId)
                        writeMessage(conn, outEp, closeMsg)
                    } catch (_: Exception) {}
                }
            } finally {
                cleanup()
                withContext(Dispatchers.Main) {
                    _connectionState.value = ConnectionState.Disconnected
                }
            }
        }
    }

    private fun cleanup() {
        isRunning.set(false)
        workerJob?.cancel()
        workerJob = null
        try {
            adbInterface?.let { iface ->
                usbConnection?.releaseInterface(iface)
            }
            usbConnection?.close()
        } catch (_: Exception) {}
        usbConnection = null
        adbInterface = null
        inEndpoint = null
        outEndpoint = null
        remoteStreamId = 0
    }

    fun destroy() {
        disconnect()
        try {
            context.unregisterReceiver(usbReceiver)
        } catch (_: Exception) {}
    }
}
