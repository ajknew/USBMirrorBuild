package com.usbscreenmirror.decoder

import android.media.MediaCodec
import android.media.MediaFormat
import android.view.Surface
import com.usbscreenmirror.model.LogLevel
import com.usbscreenmirror.model.StreamingMetrics
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.nio.ByteBuffer
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong

class H264Decoder(
    private val onLog: (String, String, LogLevel) -> Unit
) {
    companion object {
        private const val TAG = "H264Decoder"
        private const val MIME_TYPE = "video/avc"
        private const val DEFAULT_WIDTH = 1280
        private const val DEFAULT_HEIGHT = 720
    }

    private var codec: MediaCodec? = null
    private var outputSurface: Surface? = null
    private val isRunning = AtomicBoolean(false)
    private val scope = CoroutineScope(Dispatchers.Default + Job())
    private var decodeJob: Job? = null
    private var metricsJob: Job? = null

    private val inputQueue = LinkedBlockingQueue<ByteArray>(200)

    private val _metrics = MutableStateFlow(StreamingMetrics())
    val metrics: StateFlow<StreamingMetrics> = _metrics.asStateFlow()

    private val totalFrames = AtomicLong(0L)
    private val totalBytes = AtomicLong(0L)
    private val framesInWindow = AtomicLong(0L)
    private val bytesInWindow = AtomicLong(0L)

    private var videoWidth = DEFAULT_WIDTH
    private var videoHeight = DEFAULT_HEIGHT

    fun attachSurface(surface: Surface) {
        onLog(TAG, "Attaching Surface to H264Decoder", LogLevel.INFO)
        outputSurface = surface
        if (isRunning.get()) {
            restartCodec()
        }
    }

    fun detachSurface() {
        onLog(TAG, "Detaching Surface from H264Decoder", LogLevel.INFO)
        outputSurface = null
        stop()
    }

    fun start() {
        if (isRunning.getAndSet(true)) return
        onLog(TAG, "Starting H264Decoder...", LogLevel.INFO)
        initCodec()
        startDecodeLoop()
        startMetricsTracker()
    }

    private fun initCodec() {
        val surface = outputSurface
        if (surface == null || !surface.isValid) {
            onLog(TAG, "Waiting for valid Surface before initializing MediaCodec", LogLevel.WARN)
            return
        }

        try {
            codec?.stop()
            codec?.release()
        } catch (_: Exception) {}

        try {
            val format = MediaFormat.createVideoFormat(MIME_TYPE, videoWidth, videoHeight).apply {
                // Low-latency configuration for live mirroring
                setInteger(MediaFormat.KEY_LOW_LATENCY, 1)
            }
            val newCodec = MediaCodec.createDecoderByType(MIME_TYPE)
            newCodec.configure(format, surface, null, 0)
            newCodec.start()
            codec = newCodec
            onLog(TAG, "MediaCodec AVC hardware decoder initialized ($videoWidth x $videoHeight)", LogLevel.SUCCESS)
        } catch (e: Exception) {
            onLog(TAG, "Failed to initialize MediaCodec: ${e.message}", LogLevel.ERROR)
        }
    }

    private fun restartCodec() {
        stopDecodeLoop()
        initCodec()
        startDecodeLoop()
    }

    fun feedData(data: ByteArray) {
        if (!isRunning.get()) return
        totalBytes.addAndGet(data.size.toLong())
        bytesInWindow.addAndGet(data.size.toLong())

        // Offer to queue; if full, drop oldest to avoid high latency buffer bloat
        if (!inputQueue.offer(data)) {
            inputQueue.poll()
            inputQueue.offer(data)
        }
    }

    private fun startDecodeLoop() {
        decodeJob?.cancel()
        decodeJob = scope.launch(Dispatchers.IO) {
            val bufferInfo = MediaCodec.BufferInfo()
            var presentationTimeUs = 0L

            while (isActive && isRunning.get()) {
                val currentCodec = codec
                if (currentCodec == null) {
                    kotlinx.coroutines.delay(20)
                    continue
                }

                try {
                    // Feed pending input chunk
                    val chunk = inputQueue.poll()
                    if (chunk != null) {
                        val inputIndex = currentCodec.dequeueInputBuffer(10_000L) // 10ms
                        if (inputIndex >= 0) {
                            val inputBuffer: ByteBuffer? = currentCodec.getInputBuffer(inputIndex)
                            inputBuffer?.clear()
                            val writeLen = minOf(chunk.size, inputBuffer?.capacity() ?: 0)
                            inputBuffer?.put(chunk, 0, writeLen)
                            presentationTimeUs += 33_333L // approx 30fps base
                            currentCodec.queueInputBuffer(
                                inputIndex,
                                0,
                                writeLen,
                                presentationTimeUs,
                                0
                            )
                        }
                    }

                    // Drain output buffer
                    val outputIndex = currentCodec.dequeueOutputBuffer(bufferInfo, 10_000L)
                    when {
                        outputIndex >= 0 -> {
                            // Render frame to surface!
                            currentCodec.releaseOutputBuffer(outputIndex, true)
                            totalFrames.incrementAndGet()
                            framesInWindow.incrementAndGet()
                        }
                        outputIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                            val newFormat = currentCodec.outputFormat
                            val w = newFormat.getInteger(MediaFormat.KEY_WIDTH)
                            val h = newFormat.getInteger(MediaFormat.KEY_HEIGHT)
                            videoWidth = w
                            videoHeight = h
                            onLog(TAG, "Video format changed: ${w}x$h", LogLevel.INFO)
                            _metrics.value = _metrics.value.copy(
                                videoWidth = w,
                                videoHeight = h
                            )
                        }
                    }
                } catch (e: Exception) {
                    if (isRunning.get()) {
                        onLog(TAG, "Decoder loop exception: ${e.message}", LogLevel.WARN)
                    }
                }
            }
        }
    }

    private fun startMetricsTracker() {
        metricsJob?.cancel()
        metricsJob = scope.launch(Dispatchers.Default) {
            while (isActive && isRunning.get()) {
                kotlinx.coroutines.delay(1000L)
                val currentFrames = framesInWindow.getAndSet(0L)
                val currentBytes = bytesInWindow.getAndSet(0L)
                val currentBitrate = (currentBytes * 8L) / 1000L // Kbps

                _metrics.value = StreamingMetrics(
                    fps = currentFrames.toFloat(),
                    bitrateKbps = currentBitrate,
                    totalFramesDecoded = totalFrames.get(),
                    totalBytesReceived = totalBytes.get(),
                    videoWidth = videoWidth,
                    videoHeight = videoHeight,
                    isHardwareAccelerated = true
                )
            }
        }
    }

    private fun stopDecodeLoop() {
        decodeJob?.cancel()
        decodeJob = null
    }

    fun stop() {
        isRunning.set(false)
        stopDecodeLoop()
        metricsJob?.cancel()
        metricsJob = null
        inputQueue.clear()

        try {
            codec?.stop()
            codec?.release()
        } catch (_: Exception) {}
        codec = null
    }
}
